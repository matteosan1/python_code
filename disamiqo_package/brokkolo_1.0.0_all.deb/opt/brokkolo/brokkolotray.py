import random
from PyQt4 import Qt
#from PyKDE4 import kdeui

class BrokkoloTray(Qt.QDialog):
    def __init__(self):
        Qt.QDialog.__init__(self)
        self.iconGroupBox = Qt.QGroupBox()
        self.iconLabel = Qt.QLabel()
        self.iconComboBox = Qt.QComboBox()
        self.showIconCheckBox = Qt.QCheckBox()
        self.messageGroupBox = Qt.QGroupBox()
        #self.typeLabel = Qt.QLabel()
        self.durationLabel = Qt.QLabel()
        self.durationWarningLabel = Qt.QLabel()
        self.titleLabel = Qt.QLabel()
        self.bodyLabel = Qt.QLabel()
        #self.typeComboBox = Qt.QComboBox()
        self.durationSpinBox = Qt.QSpinBox()
        self.titleEdit = Qt.QLineEdit()
        self.bodyEdit = Qt.QTextEdit()
        self.showMessageButton = Qt.QPushButton()
        self.setWindowIcon(Qt.QIcon(":/images/trayicon.xpm"))
        
        self.createMessageGroupBox();
        self.iconLabel.setMinimumWidth(self.durationLabel.sizeHint().width());
        self.createActions();
        self.createTrayIcon();

        self.mainLayout = Qt.QVBoxLayout()
        self.mainLayout.addWidget(self.iconGroupBox)
        self.mainLayout.addWidget(self.messageGroupBox)
        self.setLayout(self.mainLayout)

        #self.iconComboBox.setCurrentIndex(1)
        self.trayIcon.show()
        self.setWindowTitle("Parla con Brokkolo...")
        self.resize(400, 300)
        self.timer = Qt.QTimer(self)
        Qt.QObject.connect(self.timer, Qt.SIGNAL("timeout()"), self.showMessage)
        self.timer.start(3600000);
        
    def closeEvent(self, event):
        if (self.trayIcon.isVisible()):
            self.timer.setInterval(self.durationSpinBox.value() * 60000)
            #Qt.QMessageBox.information(self, "Parla con Brokkolo...",
            #                           "The program will keep running in the system tray. To terminate the program, choose <b>Quit</b> in the context menu  of the system tray entry.")
            self.hide()
            event.ignore()
    
    def openSettings(self):
        self.show()

    def iconActivated(self, reason):
        #if (reason == Qt.QSystemTrayIcon.Trigger):
        #    self.showMessage()
        if (reason == Qt.QSystemTrayIcon.DoubleClick):
            self.showMessage()
        #elif (reason == Qt.QSystemTrayIcon.MiddleClick):
        #    self.showMessage()
         
    def showMessage(self):
        file = open("/opt/brokkolo/frasi.txt")
        lines = file.readlines()
        file.close()

        self.currentLine = random.choice(lines)
        
        self.trayIcon.showMessage("Ciao Giuseppe !", 
                                  self.currentLine, 
                                  Qt.QSystemTrayIcon.NoIcon)

    def about(self):
        Qt.QMessageBox.about(self, "About",
                             "\nParla con Brokkolo...\n\nMatteoSoftware (C)2009\n") 

    def addMessage(self):
        file = open("/opt/brokkolo/frasi.txt", "a")
        file.write(self.bodyEdit.toPlainText())
        file.close()

    def messageClicked(self):
        self.message = Qt.QMessageBox(1,
                                      "Parla con Brokkolo...",
                                      self.currentLine)
        self.message.setIconPixmap(Qt.QPixmap(":/images/mainicon.png"))
        self.message.setFont(Qt.QFont("Times", 12, Qt.QFont.Bold))
        self.message.show()

    def createMessageGroupBox(self):
        self.messageGroupBox = Qt.QGroupBox("Parla con Brokkolo Settings")

        self.durationLabel = Qt.QLabel("Intervallo:")
        self.durationSpinBox = Qt.QSpinBox()
        self.durationSpinBox.setRange(5, 60)
        self.durationSpinBox.setSuffix(" min.")
        self.durationSpinBox.setValue(15)
        
        self.bodyLabel = Qt.QLabel("Testo:")
        self.bodyEdit = Qt.QTextEdit()
        
        self.showMessageButton = Qt.QPushButton("Aggiungi Frase")
        self.showMessageButton.setDefault(True);
        
        self.messageLayout = Qt.QGridLayout()
        self.messageLayout.addWidget(self.durationLabel, 1, 0)
        self.messageLayout.addWidget(self.durationSpinBox, 1, 1)
        self.messageLayout.addWidget(self.bodyLabel, 3, 0)
        self.messageLayout.addWidget(self.bodyEdit, 3, 1, 2, 4)
        self.messageLayout.addWidget(self.showMessageButton, 5, 4)
        self.messageLayout.setColumnStretch(3, 1)
        self.messageLayout.setRowStretch(4, 1)
        self.messageGroupBox.setLayout(self.messageLayout)
        
    def createActions(self):
        
        self.settingsAction = Qt.QAction("&Settings", self)
        Qt.QObject.connect(self.settingsAction, Qt.SIGNAL("triggered()"), self.openSettings)

        self.aboutAction = Qt.QAction("&About", self)
        Qt.QObject.connect(self.aboutAction, Qt.SIGNAL("triggered()"), self.about)
        
        self.quitAction = Qt.QAction("&Quit", self)
        Qt.QObject.connect(self.quitAction, Qt.SIGNAL("triggered()"), Qt.qApp, Qt.SLOT("quit()"))
        
    def createTrayIcon(self):
        self.trayIconMenu = Qt.QMenu(self)
        self.trayIconMenu.addAction(self.settingsAction)
        self.trayIconMenu.addAction(self.aboutAction)
        self.trayIconMenu.addSeparator()
        self.trayIconMenu.addAction(self.quitAction)

        self.trayIcon = Qt.QSystemTrayIcon(self)
        self.trayIcon.setContextMenu(self.trayIconMenu)
        #pixmap = Qt.QPixmap(Qt.QString(":/images/trayicon.xpm"))
        #self.icon = Qt.QIcon()                                               
        #self.icon.addPixmap(pixmap, Qt.QIcon.Normal, Qt.QIcon.Off)    
        self.trayIcon.setIcon(Qt.QIcon(Qt.QPixmap(Qt.QString(":/images/trayicon.xpm"))))
        self.trayIcon.setToolTip("Parla con Brokkolo...")

        Qt.QObject.connect(self.showMessageButton, Qt.SIGNAL("clicked()"), self.addMessage)
        Qt.QObject.connect(self.trayIcon, Qt.SIGNAL("messageClicked()"), self.messageClicked)
        Qt.QObject.connect(self.trayIcon, Qt.SIGNAL("activated(QSystemTrayIcon::ActivationReason)"), self.iconActivated)


